plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.auris.phase0"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.auris.phase0"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-phase0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
