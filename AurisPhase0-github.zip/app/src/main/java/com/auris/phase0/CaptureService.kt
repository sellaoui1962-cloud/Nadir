package com.auris.phase0

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/** حالة مشتركة تقرؤها الواجهة كل فترة قصيرة. */
object CaptureState {
    @Volatile var running = false
    @Volatile var rmsDb = -120.0
    @Volatile var peakDb = -120.0
    @Volatile var totalFrames = 0L
    @Volatile var signalFrames = 0L
    @Volatile var startMs = 0L
    @Volatile var error: String? = null

    fun reset() {
        rmsDb = -120.0; peakDb = -120.0
        totalFrames = 0; signalFrames = 0
        startMs = System.currentTimeMillis(); error = null
    }
}

/** نقطة الربط المستقبلية: هنا يوضع Music Detector ثم Demucs/ONNX في المرحلة الأولى. */
interface AudioProcessor {
    fun process(buf: ShortArray, len: Int)
}

class PassThroughProcessor : AudioProcessor {
    override fun process(buf: ShortArray, len: Int) { /* لا معالجة في المرحلة صفر */ }
}

class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "com.auris.phase0.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_REPLAY = "replay"
        const val EXTRA_LABEL = "label"
        const val REPORT_FILE = "compat_report.csv"
        private const val CHANNEL = "auris_capture"
        private const val SAMPLE_RATE = 44100
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    private var label = ""
    private var replay = false
    private val processor: AudioProcessor = PassThroughProcessor()

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopCapture(); stopSelf(); return START_NOT_STICKY
        }
        startAsForeground()

        label = intent.getStringExtra(EXTRA_LABEL).orEmpty()
        replay = intent.getBooleanExtra(EXTRA_REPLAY, false)
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) { fail("لم يصل إذن MediaProjection"); return START_NOT_STICKY }

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projection = mpm.getMediaProjection(code, data).also { p ->
                // مطلوب على Android 14+ قبل استخدام الإسقاط
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { stopCapture(); stopSelf() }
                }, Handler(Looper.getMainLooper()))
            }
            startCapture()
        } catch (e: Exception) {
            fail("فشل البدء: ${e.message}")
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .excludeUid(Process.myUid()) // لا نلتقط صوتنا نحن عند اختبار الإعادة
            .build()

        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        record = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setAudioPlaybackCaptureConfig(cfg)
            .setBufferSizeInBytes(max(minBuf * 2, 16384))
            .build()

        if (replay) {
            val outFmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build()
            val outMin = AudioTrack.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(outFmt)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(max(outMin, 16384))
                .build().also { it.play() }
        }

        CaptureState.reset()
        CaptureState.running = true
        thread = Thread({ loop() }, "auris-capture").also { it.start() }
    }

    private fun loop() {
        val rec = record ?: return
        val buf = ShortArray(2048)
        try {
            rec.startRecording()
            while (CaptureState.running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) { CaptureState.error = "خطأ قراءة: $n"; break }
                if (n == 0) continue

                var sum = 0.0
                var peak = 0
                for (i in 0 until n) {
                    val s = buf[i].toInt()
                    sum += s.toDouble() * s
                    val a = abs(s)
                    if (a > peak) peak = a
                }
                val rms = sqrt(sum / n)
                val rmsDb = if (rms < 1.0) -120.0 else 20 * log10(rms / 32768.0)
                val peakDb = if (peak < 1) -120.0 else 20 * log10(peak / 32768.0)

                CaptureState.rmsDb = rmsDb
                if (peakDb > CaptureState.peakDb) CaptureState.peakDb = peakDb
                CaptureState.totalFrames++
                if (rmsDb > -60.0) CaptureState.signalFrames++

                processor.process(buf, n)
                track?.write(buf, 0, n)
            }
        } catch (e: Exception) {
            CaptureState.error = "استثناء: ${e.message}"
        }
    }

    private fun stopCapture() {
        if (!CaptureState.running && thread == null) return
        CaptureState.running = false
        try { thread?.join(500) } catch (_: InterruptedException) {}
        thread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release(); record = null
        try { track?.stop() } catch (_: Exception) {}
        track?.release(); track = null
        projection?.stop(); projection = null
        writeReport()
    }

    private fun writeReport() {
        if (CaptureState.totalFrames == 0L) return
        val f = File(filesDir, REPORT_FILE)
        if (!f.exists()) {
            f.writeText("time,app_label,device,android_sdk,duration_s,signal_ratio,peak_db,error\n")
        }
        val dur = (System.currentTimeMillis() - CaptureState.startMs) / 1000
        val ratio = CaptureState.signalFrames.toDouble() / CaptureState.totalFrames
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val lbl = label.replace(",", " ")
        f.appendText(
            "$time,$lbl,${Build.MANUFACTURER} ${Build.MODEL},${Build.VERSION.SDK_INT}," +
                "$dur,${"%.2f".format(Locale.US, ratio)},${"%.1f".format(Locale.US, CaptureState.peakDb)}," +
                "${CaptureState.error ?: ""}\n"
        )
    }

    private fun fail(msg: String) {
        CaptureState.error = msg
        CaptureState.running = false
        stopSelf()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "AURIS Capture", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("AURIS Phase 0")
            .setContentText("اختبار التقاط الصوت قيد التشغيل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
