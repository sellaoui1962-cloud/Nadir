package com.auris.phase0

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private val REQ_PERM = 1
    private val REQ_PROJECTION = 2

    private lateinit var etLabel: EditText
    private lateinit var swReplay: Switch
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvLevel: TextView
    private lateinit var bar: ProgressBar
    private val ui = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 300) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        fun tv(text: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            this.text = text; textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

        root.addView(tv("AURIS — المرحلة صفر", 22f, true))
        root.addView(tv("اختبار: هل يمكن التقاط صوت التطبيق؟ وهل يبقى الصوت الأصلي مسموعًا؟"))

        etLabel = EditText(this).apply {
            hint = "اسم التطبيق قيد الاختبار (YouTube, TikTok...)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(etLabel)

        swReplay = Switch(this).apply { text = "إعادة تشغيل الصوت الملتقط (اختبار الصوت المزدوج)" }
        root.addView(swReplay)

        btnStart = Button(this).apply { text = "ابدأ الالتقاط"; setOnClickListener { onStart() } }
        btnStop = Button(this).apply {
            text = "أوقف وسجّل النتيجة"
            setOnClickListener { stopService(); }
        }
        root.addView(btnStart); root.addView(btnStop)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar)
        tvLevel = tv("المستوى: —")
        tvStatus = tv("الحالة: متوقف", 16f, true)
        root.addView(tvLevel); root.addView(tvStatus)

        root.addView(Button(this).apply {
            text = "مشاركة تقرير التوافق"
            setOnClickListener { shareReport() }
        })
        root.addView(tv(
            "طريقة الاختبار: اكتب اسم التطبيق ← ابدأ ← افتح التطبيق وشغّل مقطعًا فيه صوت ← " +
                "راقب المستوى ← أوقف. فعّل مفتاح الإعادة لتسمع هل يظهر صوت مزدوج."
        ))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); ui.post(ticker) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(ticker) }

    private fun onStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_PERM) else askProjection()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                askProjection()
            else tvStatus.text = "الحالة: إذن الميكروفون مرفوض (مطلوب لواجهة الالتقاط)"
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_CODE, resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                    putExtra(CaptureService.EXTRA_REPLAY, swReplay.isChecked)
                    putExtra(CaptureService.EXTRA_LABEL, etLabel.text.toString())
                }
                startForegroundService(i)
            } else tvStatus.text = "الحالة: رُفض إذن التقاط الشاشة/الصوت"
        }
    }

    private fun stopService() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
    }

    private fun refresh() {
        val s = CaptureState
        btnStart.isEnabled = !s.running
        btnStop.isEnabled = s.running
        bar.progress = (((s.rmsDb + 80) / 80.0) * 100).coerceIn(0.0, 100.0).toInt()
        tvLevel.text = "المستوى: %.1f dBFS | الذروة: %.1f".format(s.rmsDb, s.peakDb)

        tvStatus.text = when {
            s.error != null -> "الحالة: ${s.error}"
            !s.running -> "الحالة: متوقف"
            else -> {
                val secs = (System.currentTimeMillis() - s.startMs) / 1000
                when {
                    s.signalFrames > 0 -> "الحالة: ✅ الصوت يُلتقط (${secs}ث)"
                    secs >= 5 -> "الحالة: ⚠️ صمت — المصدر غير مدعوم أو لا يوجد صوت"
                    else -> "الحالة: بانتظار صوت..."
                }
            }
        }
    }

    private fun shareReport() {
        val f = File(filesDir, CaptureService.REPORT_FILE)
        val text = if (f.exists()) f.readText() else "لا توجد نتائج بعد"
        startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
            }, "مشاركة التقرير"))
    }
}
